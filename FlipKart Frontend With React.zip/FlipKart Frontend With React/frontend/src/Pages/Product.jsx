import React, { useContext } from 'react'
import { ShopContext } from '../Context/ShopContext';
import { useParams } from 'react-router-dom';
import Bredcrums from '../Components/Bredcrums/BredCrums';
import ProductDisplay from '../Components/ProductDisplay/ProductDisplay';
import Description from '../Components/Description/Description';
import RelatedProducts from '../Components/RelatedProducts/RelatedProducts';

// Defining the Product functional component
const Product = () => {
    // Using React Context to get access to all products from ShopContext
  const {all_product} = useContext(ShopContext);
    // Getting the dynamic productId from the URL using useParams (React Router hook)
  const {productId} = useParams();
    // Finding the product from all products that matches the productId from the URL
  const product = all_product.find((e)=> e.id === parseInt(productId));
   // parseInt ensures productId (string from URL) is compared as a number
  return (
        // Main container for the Product details page
    <div>
            {/* Breadcrumbs component to show navigation path based on the selected product through props */}
      <Bredcrums product={product}/>
            {/* ProductDisplay component to show detailed product information */}
      <ProductDisplay product={product}/>
            {/* Description component for additional product details or specifications */}
      <Description/>
            {/* RelatedProducts component to suggest other similar products */}
      <RelatedProducts/>
    </div>
  )
}

export default Product