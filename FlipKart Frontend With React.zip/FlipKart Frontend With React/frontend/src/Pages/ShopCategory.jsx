import React, { useContext, useState } from 'react'
import "../CSS/ShopCategory.css"
import { ShopContext } from '../Context/ShopContext'
import dropdown_icon from "../assets/dropdown_icon.png"
import Item from '../Components/Item/Item'

// ShopCategory functional component that receives props like banner image and category type
const ShopCategory = (props) => {
  // Using React Context to access the all_product array from ShopContext
  const {all_product}=useContext(ShopContext);
  
  return (
        // Main container for the shop category page
    <div className='shop-category'>
            {/* Displaying the category-specific banner image */}
      <img className='shopcategory-banner' src={props.banner} alt="" />
            {/* Index and sorting section */}
      <div className='shopcategory-indexSort'>
         {/* Showing static text for products being displayed */}
        <p>
          <span>Showing 1-12</span> out of 36 products
        </p>
         {/* Sort by option (currently static) with a dropdown icon */}
        <div className='shopcategory-sort'>
          Sort by <img src={dropdown_icon} alt="" height="20px"/>
        </div>
      </div>
       {/* Product listing section */}
      <div className="shopcategory-products">
           {/* Looping through all products to display items that match the selected category */}
        {all_product.map((item,i)=>{
                    // If the item's category matches the current category prop, render the item
          if(props.category === item.category){
            return <Item key={i} // Unique key for each item (index used here)
            id={item.id}  // Passing product ID
            name={item.name}  // Passing product name
            image={item.image}   // Passing product image
            new_price={item.new_price}  // Passing new (discounted) price
            old_price={item.old_price}/> // Passing old (original) price
          }else{
            return null;
          }
        })}

  
      </div>
     


      <div className="shopcategory-loadmore">
        Explore More
      </div>
    </div>
  )
}

export default ShopCategory