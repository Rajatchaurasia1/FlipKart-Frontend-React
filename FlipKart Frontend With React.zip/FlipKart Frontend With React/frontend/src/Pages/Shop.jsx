import React from 'react'
import Hero from '../Components/Hero/Hero'
import Popular from '../Components/popular/Popular'
import Offers from '../Components/Offers/Offers'
import NewCollections from "../Components/NewCollections/NewCollections"
import Newsletter from '../Components/NewsLetter/Newsletter'
import Footer from '../Components/Footer/Footer'


const Shop = () => {
  return (
    <div>
       {/* Rendering the Hero section, typically a banner or main visual */}
      <Hero/>
      {/* Rendering the Popular section, showcasing popular products */}
      <Popular/>
      {/* Rendering the Offers section, likely showing special deals or discounts */}
      <Offers/>
       {/* Rendering the New Collections section, showcasing newly added products */}
      <NewCollections/>
      {/* Rendering the Newsletter section, for email subscription or updates */}
      <Newsletter/>
      
    </div>
  )
}

export default Shop