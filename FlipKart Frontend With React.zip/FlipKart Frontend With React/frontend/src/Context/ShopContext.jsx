// Importing required modules from React
import React, { createContext, useState } from "react";
import all_product from "../assets/all_product";
import CartItems from "../Components/CartItems/CartItems";

export const ShopContext = createContext(null);
// Function to create the default cart structure with all item counts initialized to 0
const getDefaultCart = () => {
    let cart = {};
    // Looping through all products and initializing their count to 0 in the cart
    for (let index = 0; index < all_product.length + 1; index++) {
        cart[index] = 0
    } return cart;
}
// Provider component that wraps the application and supplies cart-related state and functions
const ShopContextProvider = (props) => {
    // State to manage cart items, initialized using the getDefaultCart function
    const [cartItems, setCartItems] = useState(getDefaultCart())

    // Function to add an item to the cart
    const addTocart = (itemId) => {
        // Updating the quantity of the selected item in the cart
        setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }));
        console.log(cartItems); // Logging cart state for debugging


    }
    // Function to remove an item from the cart
    const removeFromCart = (itemId) => {
        // Decreasing the quantity of the selected item in the cart
        setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] - 1 })
        )
    }

    // Function to calculate the total price of all items in the cart
    const getTotalCartAmount = () => {
        let totalAmount = 0;
        // Looping through all cart items
        for (const item in cartItems) {
            // Processing only items with quantity greater than 0
            if (cartItems[item] > 0) {
                // Finding product details by matching the item ID
                let itemInfo = all_product.find((product) => product.id === Number(item))
                // Calculating the total price for the item based on its quantity

                totalAmount += itemInfo.new_price * cartItems[item];
            }

        }
        return totalAmount; // Returning the total cart value
    }

    // Function to count the total number of items in the cart
    const getTotalCartItems = () => {
        let totalItmes = 0;
        // Looping through all cart items
        for (const item in cartItems) {
            // Processing only items with quantity greater than 0
            if (cartItems[item] > 0) {
                // Adding the item quantity to the total count
                totalItmes += cartItems[item];
            }

        }
        return totalItmes; // Returning the total number of items in the cart
    }

    // Preparing the values and functions to share globally using context
    const contextValue = { getTotalCartItems, getTotalCartAmount, all_product, cartItems, addTocart, removeFromCart };
    return (
        // Providing the context to all children components of this provider

        <ShopContext.Provider value={contextValue}>
            {props.children}
        </ShopContext.Provider>
    )
}

// Exporting the ShopContextProvider for use in other parts of the application
export default ShopContextProvider;