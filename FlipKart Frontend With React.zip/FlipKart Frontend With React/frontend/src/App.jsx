import Navbar from "./Components/Navbar/Navbar"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Shop from "./Pages/Shop"
import ShopCategory from "./Pages/ShopCategory"
import Product from "./Pages/Product"
import Cart from "./Pages/Cart"
import LoginSignup from "./Pages/LoginSignup"
import Footer from "./Components/Footer/Footer"
import men_banner from "./assets/banner.jpg"
import women_banner from "./assets/women_banner.avif"
import kids_banner from "./assets/kids_banner.jpg"
function App() {

  return (
    <div >

      {/* BrowserRouter wraps the entire app to enable client-side routing */}
      <BrowserRouter>
        {/* Navbar component that stays visible on all pages */}
        <Navbar />
        {/* Routes define the various pages of the application */}
        <Routes>
          {/* Home route displaying the Shop component */}
          <Route path="/" element={<Shop />} />
          {/* Men's category page with a specific banner and category passed as props */}
          <Route path="/mens" element={<ShopCategory banner={men_banner} category="men" />} />
          {/* Women's category page with a specific banner and category passed as props */}
          <Route path="/womens" element={<ShopCategory banner={women_banner} category="women" />} />
          {/* Kids' category page with a specific banner and category passed as props */}
          <Route path="/kids" element={<ShopCategory banner={kids_banner} category="kid" />} />
          {/* Route for the product listing page */}
          <Route path="/product" element={<Product />} />
          {/* Dynamic route for individual product detail pages based on productId */}
          <Route path="/product/:productId" element={<Product />} />
          {/* Route for the shopping cart page */}
          <Route path="/cart" element={<Cart />} />
          {/* Route for the login and signup page */}
          <Route path="/login" element={<LoginSignup />} />
        </Routes>
        <Footer />
      </BrowserRouter>

    </div>

  )
}

export default App
