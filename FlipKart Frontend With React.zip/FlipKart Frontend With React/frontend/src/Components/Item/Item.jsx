import React from 'react'
import "./Item.css"   // import item css here 
import { Link } from 'react-router-dom'
const Item = (props) => {
  return (
    <div className='item'>
      {/* Wrapping the image in a Link that navigates to the product details page based on the product ID */}
      <Link to={`/product/${props.id}`}
      >
        {/* Product image with an onClick event to scroll to the top of the page when clicked */}
        <img onClick={window.scrollTo(0, 0)} // // Scrolls to top when image is clicked
          src={props.image} // Product image source through Props on assets
          // Alt text for the image (can be improved for accessibility)
          alt="" />
      </Link>

      {/* these data come from assets/data.js  */}

      {/* Displaying the product name throguh props */}
      <p>{props.name}</p>
      <div className='item-prices'>
        <div className="item-price-new">
          {/* Container for displaying new and old prices */}
          ${props.new_price}
        </div>
        {/* Displaying the old (original) price */}
        <div className="item-price-old">
          {props.old_price}
        </div>
      </div>
    </div>
  )
}

export default Item