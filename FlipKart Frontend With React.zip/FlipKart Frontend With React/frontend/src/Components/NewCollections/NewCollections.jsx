import React from 'react'
import "./NewCollections.css"
import new_collections from '../../assets/newcollections'
import Item from '../Item/Item'
const NewCollections = () => {
  return (
    // Main container div for the New Collections section
    <div className='newcollections'>
      <h1>NEW COLLECTIONS</h1>
      <hr />

      {/* Container for listing all the new collection items */}
      <div className='collections'>
        {/* Mapping through the new_collections array to render each item */}
        {new_collections.map((item, i) => {
          // Rendering the Item component for each product in the new collection
          return <Item
            key={i} // Unique key for each item (index in this case)
            id={item.id}  // Passing product ID as prop
            name={item.name}  // Passing product name as prop
            image={item.image}  // Passing product image as prop
            new_price={item.new_price} // Passing new price as prop
            old_price={item.old_price}  // Passing old price as prop
          />
        })}
      </div>
    </div>
  )
}

export default NewCollections