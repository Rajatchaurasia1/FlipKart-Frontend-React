import React, { useContext } from 'react'
import "./ProductDisplay.css"
// Importing assets for star icons
import star_icon from "../../assets/star_icon.png"
import star_dull_icon from "../../assets/star_dull_icon.png";
// Importing context to access shared state and functions
import { ShopContext } from '../../Context/ShopContext';
// Functional component to display detailed product information
const ProductDisplay = (props) => {
    // Destructuring product data from props
  const { product } = props;
    // Accessing addTocart function from ShopContext using useContext hook
  const { addTocart } = useContext(ShopContext);
  return (
    <div className='productdisplay'>
      <div className="productdisplay-left">
        <div className="productdisplay-img-list">
          <img src={product.image} alt="" height="150px" />
          <img src={product.image} alt="" height="150px" />
          <img src={product.image} alt="" height="150px" />
        </div>
        <div className='productdisplay-img'>
          <img className='productdisplay-main-img' src={product.image} alt="" height="300px" />
        </div>
      </div>
      <div className="productdisplay-right">
        <h1>{product.name}</h1>
        <div className="productdisplay-right-star">
          <img src={star_icon} alt="" height="20px" />
          <img src={star_icon} alt="" height="20px" />
          <img src={star_icon} alt="" height="20px" />
          <img src={star_icon} alt="" height="20px" />
          <img src={star_dull_icon} alt="" height="20px" />
          <p>(130)</p>
        </div>
        <div className="productdisplay-right-prices">
          <div className="productdisplay-right-price-old">
            ${product.old_price}
          </div>
          <div className="productdisplay-right-price-new">
            ${product.new_price}
          </div>
        </div>
        <div className="productdisplay-right-description">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, eaque. Amet reiciendis minus modi eum soluta hic autem, rem corrupti quibusdam? Quam omnis saepe et expedita ratione, quasi unde repudiandae.
        </div>
        <div className='productdisplay-right-size'>
          <h1>Select Size</h1>
          <div className="productdisplay-right-sizes">
            <div>S</div>
            <div>M</div>
            <div>L</div>
            <div>XL</div>
            <div>XXL</div>
          </div>
        </div>

        {/* Button to add the current product to the shopping cart */}
        <button onClick={() => { addTocart(product.id) }}>ADD TO CART</button>
        {/* Section to display the product's category information */}
        <div className="productdisplay-right-category">
          {/* Displaying product categories (can be made dynamic if categories come from product data) */}
          <span>Category:<span>Women ,T-Shirt , Crop Top</span></span>
        </div>
        {/* Section to display product tags */}
        <div className="productdisplay-right-category">
          {/* Displaying product tags (currently static text, can also be made dynamic) */}
          <span>Tags:<span>Modern ,Latest , Trend Shorts</span></span>
        </div>
        {/* Closing divs from parent containers (likely wrapping the entire product detail section) */}

      </div>
    </div>

  )
}

export default ProductDisplay