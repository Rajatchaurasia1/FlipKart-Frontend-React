import React, { useContext } from 'react'
import "./CartItems.css" // Importing CSS for styling
import remove_icon from "../../assets/remove.webp" // Importing remove icon image
import { ShopContext } from '../../Context/ShopContext' // Importing context to access shared cart data

// Functional component to display and manage cart items
const CartItems = () => {
    // Destructuring required data and functions from ShopContext
    const { getTotalCartAmount, all_product, cartItems, removeFromCart } = useContext(ShopContext);
    return (
        <div className='cartItems'>
            <div className="cartitems-format-main">
                <p>Products</p>
                <p>Title</p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
                <p>Remove</p>
            </div>
            <hr />
            {/* Displaying all cart items */}
            {all_product.map((e) => {
                // Displaying only those products which are added to the cart (quantity > 0)
                if (cartItems[e.id] > 0) {
                    return <div>
                        <div className='cartItems-format cartitems-format-main'>
                            <img src={e.image} alt="" height="100px" />
                            <p>{e.name}</p>
                            {/* Total price for the item (price * quantity) */}
                            <p>${e.new_price}</p>
                            <button className='cartitems-quantity'>
                                {cartItems[e.id]}
                            </button>
                            <p>{e.new_price * cartItems[e.id]}</p>
                            <img src={remove_icon} alt="" onClick={() => removeFromCart(e.id)} height="20px" />
                        </div>
                        <hr />
                    </div>
                }
                return null;
            })}
            <div className="cartitems-down">
                <div className="cartitems-total">
                    <h1>cart Totals</h1>
                    <div>
                        <div className="cartitems-total-item">
                            <p>Subtotal</p>
                            <p>${getTotalCartAmount()}</p>
                        </div>
                        <hr />
                        <div className="cartitems-total-item">
                            <p>Shipping Fee</p>
                            <p>Free</p>
                        </div>
                        <hr />
                        <div className="cartitems-total-item">

                            {/* Final total section */}
                            <p>Total</p>
                            <p>${getTotalCartAmount()}</p>
                        </div>
                    </div>
                    {/* Checkout button */}

                    <button>PROCEED TO CHECKOUT</button>
                </div>
                <div className="cartitems-promocode">
                    <p>If you have a promo code, Enter it here</p>
                    <div className="cartitems-promobox">
                        {/* Promo code input field */}
                        <input type='text' placeholder='promo code' />
                        {/* Promo code submission button (currently not functional) */}
                        <button>submit</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default CartItems