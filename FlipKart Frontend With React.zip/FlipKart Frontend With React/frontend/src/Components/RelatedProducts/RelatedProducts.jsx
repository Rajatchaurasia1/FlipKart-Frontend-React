import React from 'react'
import "./RealatedProducts.css" // Importing CSS file for styling the RelatedProducts component
import Item from '../Item/Item' // Importing the Item component to display individual product items
import data_product from '../../assets/data' // Importing product data to be used in the related products list

// Functional component to display a list of related products

const RelatedProducts = () => {
  return (
    <div className='relatedproducts'>
        <h1>Related Products</h1>
        <hr/>
        <div className="relatedproducts-item">
                  {/* Mapping over the product data array and rendering each product as an Item component */}
            {data_product.map((item,i)=>{
               // Rendering the Item component for each product
            // Passing necessary product details as props to the Item component
                 return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
            })}
        </div>
    </div>
  )
}

export default RelatedProducts