import React from 'react'
import "./BredCrums.css";
// Importing arrow icon used in breadcrumb navigation
import arrow_icon from "../../assets/arrow_icon.png"
// Functional component to render breadcrumb navigation based on product info
const Bredcrums = (props) => {
  // Destructuring the product object passed via props
  const { product } = props;
  return (
    <div className='bredcrums'>
      {/* Rendering the breadcrumb path:
          Home > SHOP > product category > product name */}
      Home <img src={arrow_icon} alt="" height="10px" /> SHOP <img src={arrow_icon} alt="" height="10px" />{product.category} <img src={arrow_icon} alt="" height="10px" /> {product.name}
    </div>
  )
}

export default Bredcrums